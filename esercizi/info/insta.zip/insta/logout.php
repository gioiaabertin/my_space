<?php
session_start();
include 'conn.php';
$_SESSION["USER"] = null;
header("location: index.php");
?>