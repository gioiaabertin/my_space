<?php
session_start();
include 'conn.php';


$msg = "";
$pw=md5($_POST["this_pw"]);
$chi=$_POST["this_user"];
//se l'user non è tutti caratteri => msg = messaggio errore

$sql="SELECT * FROM utenti WHERE username =? AND pw =?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ss",$chi ,$pw); //erorre
$stmt->execute();
//$stmt->store_result();
$result = $stmt->get_result();
if ($result->num_rows == 1 /* && $msg == ""*/)
   { 
    $_SESSION["USER"] = $_POST["this_user"];
      $msg = $_POST["this_user"];}
else
    $msg = "login errato";


    header("location: index.php?msg=" . $msg);
?>