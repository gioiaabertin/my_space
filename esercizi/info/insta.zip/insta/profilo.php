<?php

include 'conn.php';
session_start();

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="formato.css">
</head>

<body>
    <div class="galleria">
        <?php
                $sql = "SELECT * FROM utenti WHERE id='" . $_GET["id"] . "'";



        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<h1>" . $row["username"] . "</h1><br>";
                $_SESSION['ckuser'] = $row["username"];
                echo "<br>" . $row["descrizione"];
            }
        }

        $sql = "SELECT * FROM foto WHERE id_prop='" . $_GET["id"] . "'";


        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $id = $row["id"];
                echo
                    "<br> <figure class='galleria__elemento galleria__elemento$id'><img id='myImg$id' src='./imm/" . $row["path"] . ".jpg' alt='" . $row["descr"] . "'  class='galleria__immagine' onclick = 'clicked($id)'/>
        <div id='myModal$id' class='modal'>
            <span class='close'>&times;</span>
            <img class='modal-content' id='img$id'>
        <div id='caption$id'></div>
        </div>";


            }
        }
      //  if ((isset($_SESSION["USER"]) && $_SESSION["USER"] == $SESSION["ckuser"])) {
           // echo "<a href='caricafoto.php?id=" . $_SESSION["ckuser"].",".$_GET["id"]  . "'>nuova foto</a>" 
            
      //    echo "<form action='upload.php?user=" . $_SESSION["ckuser"].",".$_GET["id"]  . "' method='post'> <p>upload foto: </p> <input type='file' name='this_foto' id='this_foto'>  <p>descrizione: </p> <input type='text' name='this_desc' id='this_desc'> <input type='submit' value='inserisci'> </form>";
      //  }
        if (isset($_SESSION["USER"]) && $_SESSION["USER"] == $_SESSION["ckuser"])
         {   echo "<a href='logout.php'>esci, disconnetti ciao maria io esco</a><br>";
             echo "<form action='upload.php?user=" . $_GET["id"]  . "' method='post'> <p>upload foto: </p> <input type='file' name='this_foto' id='this_foto'>  <p>descrizione: </p> <input type='text' name='this_desc' id='this_desc'> <input type='submit' value='inserisci'> </form>";
        }
        else
            echo "<a href='accedi.php'>accedo al mio profilo</a><br>";
        ?>

        <script>
        // Get the modal

        // Get the <span> element that closes the modal


        // When the user clicks on <span> (x), close the modal


        function clicked(elemId) {
            var modal = document.getElementById("myModal" + elemId);
            var img = document.getElementById("myImg" + elemId);
            var modalImg = document.getElementById("img" + elemId);
            var captionText = document.getElementById("caption" + elemId);
            modal.style.display = "block";
            modalImg.src = img.src;
            captionText.innerHTML = img.alt;
            var span = document.getElementsByClassName("close")[elemId - 1];
            span.onclick = function() {
                modal.style.display = "none";
            }
        }
        </script>
    </div>
</body>

</html>