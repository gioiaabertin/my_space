<?php
session_start();
include 'conn.php';
$id=$_GET["user"];
$user= $_SESSION["ckuser"];

if ($user == $_SESSION["USER"]) {
     
    $path=$_POST["this_foto"];
    $descr= $_POST["this_desc"];
    
    $query = "INSERT INTO utenti(path,descr,id_prop) VALUES (?,?,?)";
    $stmt = $sql->prepare($query);
    $param_type = "ssi";
    $param = $path . ',' .$descr.','.$id;
    $stmt->bind_param($param_type.",".$param);
    $stmt = execute();
    header("location: index.php");
}
if (!$conn->query($sql)) {
    $msg = "inserimento foto NON avvenuto!"; //sistemato la logica (la tua era ridondante nelle chiamate)
    header("location: index.php" . ($msg == "" ? "" : "?msg=$msg"));
} else
    header("location: index.php");
?>