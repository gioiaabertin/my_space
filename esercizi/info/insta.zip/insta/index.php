<?php
session_start();
include 'conn.php';

if (isset($_GET["msg"]) && $_GET["msg"] == "login errato")
    echo "<script>alert('login errato!!');</script>";
else if(isset($_GET["msg"]))
    echo "BENVENUTO <b>" . $_GET["msg"]."</b>!<br>";
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="formato.css">
</head>

<body>
    <?php
     if(isset($_SESSION["USER"]))
   echo "<a href='logout.php'>esci no maria io esco</a>" ;
     else  echo " <a href='accedi.php'>accedo al mio profilo</a>";
     

   // if (isset($_GET['msg'])) {
  //      echo '<h1>' . $_GET['msg'] . '</h1>';
  //      echo "<script>alert('errore!!');</script>";
  //  }
    ?>

    <table>
        <tr>
            <th>username</th>
            <th>descrizione</th>
        </tr>
        <?php $sql = "SELECT * FROM utenti ";

       // if (isset($_GET["generi"]) && $_GET["generi"] != "1") {
         //   $sql .= "WHERE Genere = '" . $_GET["generi"] . "'";
        //}

        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $_SESSION["id"] = $row["id"];
                echo "<tr><th> <a href='profilo.php?id=" . $row["id"] . "'>" . $row["username"] . "</a>" . "</th><th>" . $row["descrizione"] . "</th></tr>";

            }
        }

        ?>

</body>

</html>