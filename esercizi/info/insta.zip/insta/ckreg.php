<?php
session_start();
include 'conn.php';

if ($_POST["this_pw"] == $_POST["this_pw2"]) {
    $pw = $_POST["this_pw"];

    $_SESSION["USER"] = $_POST["this_user"];

    $sql = "INSERT INTO utenti(username,pw) VALUES (?,?)";
    $param_type = "ss";
    $param = $_POST["this_user"] . ',' . md5($pw);
    $result = $db->executeQuery('insert', $sql, $param_type, $param);
    header("location: index.php");
}
if (!$conn->query($sql)) {
    $msg = "inserimento NON avvenuto!"; //sistemato la logica (la tua era ridondante nelle chiamate)
    header("location: index.php" . ($msg == "" ? "" : "?msg=$msg"));
} else
    header("location: index.php");
?>